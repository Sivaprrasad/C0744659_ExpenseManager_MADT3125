package com.example.sivaprrasad.expensemanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class GraphActivity extends AppCompatActivity {

    private Button logout;
    private Spinner spMonth;
    private String []monthList = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        logout = (Button)findViewById(R.id.btnLogout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(GraphActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });

        spMonth = findViewById(R.id.monthSpinner);

        ArrayAdapter<String> mStringArrayAdapter = new ArrayAdapter<>(GraphActivity.this,
                android.R.layout.simple_spinner_dropdown_item, monthList);

        spMonth.setAdapter(mStringArrayAdapter);




        spMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
            {
                Toast.makeText(GraphActivity.this, monthList[i], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView)
            {
                Toast.makeText(GraphActivity.this, "onNothingSelected", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
